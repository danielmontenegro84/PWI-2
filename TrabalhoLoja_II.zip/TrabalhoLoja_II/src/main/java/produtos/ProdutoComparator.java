package produtos;
import java.util.Comparator;

public class ProdutoComparator implements Comparator<Produto> {

	@Override
	public int compare(Produto produto1, Produto produto2) {
		if(produto1.getValorUnitario() == produto2.getValorUnitario()) return 0;
		if(produto1.getValorUnitario() > produto2.getValorUnitario()) return 1;
		return -1;
	}
}
