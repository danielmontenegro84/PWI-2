package compras;

import java.io.Serializable;
import java.util.TreeSet;
import javax.persistence.*;
import classes.GeneratedValue;
import produtos.*;

/**
 * Entity implementation class for Entity: Carrinho
 *
 */
@Entity

public final class Carrinho implements Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="idCarrinho")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private double total;
	private static int totalProdutos;
	TreeSet<Produto>produtos;

	/*
	public Carrinho() {
		super();
	}
	*/
	
	public Carrinho() {
		produtos = new TreeSet<>();
	}
		
	@Override
	public boolean cadastrar(Produto produto) {
		
		return produtos.add(produto);
	}
	
	@Override
	public String formatar() {
		String aux = "";
		for (Produto p : produtos) {
			if(p!=null)
				aux += p.toString() + "\n";
		}
		return aux;
	}	
		
	@Override
	public int totalizar() {
		return produtos.size();
	}
	
	@Override
	public boolean pesquisar(Produto p) {
		return produtos.contains(p);
	}
	
	@Override
	public boolean remover(Produto p) {
		
		return produtos.remove(p);
		
	}
	
	public static int getTotalProdutos() {
		return totalProdutos;
	}
	
	public double calcularTotal() {
		 return totalProdutos - total;
	}
	
	public void exibirHistorico() {
		System.out.println("Carrinho chegou a " + totalProdutos + "produtos");
		System.out.println("Carrinho ficou com " + (totalProdutos - produtos.size()) + " no fechamento compra.");
	}
}
   
}
