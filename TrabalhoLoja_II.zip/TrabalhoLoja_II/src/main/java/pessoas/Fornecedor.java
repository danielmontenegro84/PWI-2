package pessoas;

import java.io.Serializable;
import javax.persistence.*;

/**
 * Entity implementation class for Entity: Fornecedor
 *
 */
@Entity

public class Fornecedor extends PessoaJuridica implements Comparable<Fornecedor> {

	
	private static final long serialVersionUID = 1L;
	//@Id
	@Column(name="idFornecedor")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String endereco;
	private String telefone;
	private String email;

	public Fornecedor() {
		super();
	}
	
	public Fornecedor(String razaoSocial, String cnpj, String endereco, String telefone, String email) {
		super(razaoSocial, cnpj);
		this.endereco = endereco;
		this.telefone = telefone;
		this.email = email;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public int compareTo(Fornecedor f) {
		return this.getRazaoSocial().compareTo(f.getRazaoSocial());
	}
}
