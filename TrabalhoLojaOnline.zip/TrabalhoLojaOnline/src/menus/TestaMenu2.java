package menus;

import compras.*;
import pessoas.*;
import produtos.*;
import java.util.*;
import javax.swing.*;


public class TestaMenu2 {

	public static void main(String[] args) {
		Produto produto1 = new Produto("Livro", 50.00, 001);
		Produto produto2 = new Produto("Caderno", 10.00, 002);
		Produto produto3 = new Produto("Mochila",70.00, 003);
		Carrinho carrinho = new Carrinho();
		//Menu menu = new Menu();
		
		while(true) {
			switch(montaMenu()) {
			case 1: /* cadastrar um carrinho */
				// Carrinho carrinho = new Carrinho();
				carrinho.cadastrar(produto1);
				carrinho.cadastrar(produto2);
				carrinho.cadastrar(produto3);
				break;
			case 2: /* listar itens do carrinho maior/menor preco */
				ProdutoComparator comparator = new ProdutoComparator();
				TreeSet<Produto> conjunto = new TreeSet<>(comparator);
				conjunto.addAll(carrinho.getProdutos());
				JOptionPane.showMessageDialog(null, "Itens por preço: \n" + conjunto.descendingSet());
				break;
			case 3: /* listar produtos do carrinho pelo nome */
				JOptionPane.showMessageDialog(null, "Itens" + carrinho.formatar());
				break;
			case 4: /* remover um produto do carrinho */
				int codProd = Integer.parseInt(JOptionPane.showInputDialog("Informe o item que deseja remover do carrinho: "));
				if(codProd == 001) {
					JOptionPane.showMessageDialog(null, "Item removido." + carrinho.remover(produto1));
				} else if(codProd == 002) {
					JOptionPane.showMessageDialog(null, "Item removido." + carrinho.remover(produto2));
				} else if(codProd == 003) {
					JOptionPane.showMessageDialog(null, "Item removido." + carrinho.remover(produto3));
				} else {
					JOptionPane.showMessageDialog(null, "Item não encontrado.");
				}
				break;
			case 5: /* mostrar histórico */
				JOptionPane.showMessageDialog(null, "Número máximo de itens no carrinho: " + carrinho.exibirHistorico1());
				JOptionPane.showMessageDialog(null, "Itens removidos: " + carrinho.exibirHistorico3());
				JOptionPane.showMessageDialog(null, "Número final de itens no carrinho: " + carrinho.exibirHistorico2());
				break;
			case 6: /* opcao sair */
				System.exit(0);
				break;				
			}
		}
	}
	public static int montaMenu() {
		String menu = "1 - cadastrar um carrinho\n" + "2 - listar itens do carrinho maior/menor preco\n"
				+ "3 - listar produtos do carrinho pelo nome\n"
				+ "4 - remover um produto do carrinho\n" + "5 - mostrar histórico compra\n" + "6 - sair";
		return Integer.parseInt(JOptionPane.showInputDialog(menu));
	}
}
