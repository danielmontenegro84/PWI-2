package produtos;

import java.util.Objects;
import pessoas.*;
import compras.*;

public class Produto implements Comparable<Produto>{
	
	private String nome;
	private String descricao;
	private double valorUnitario;
	private Fornecedor fornecedor;
	private int codigo; /* para facilitar na hora de pesquisar */
	
	public Produto() {}
	public Produto(String nome, String descricao, double valorUnitario, Fornecedor fornecedor, int codigo) {
		this.nome=nome;
		this.descricao = descricao;
		this.valorUnitario = valorUnitario;
		this.fornecedor = fornecedor;
		this.codigo = codigo;
	}
	public Produto(String nome, double valorUnitario, int codigo) {
		this.nome=nome;
		this.valorUnitario=valorUnitario;
		this.codigo=codigo;
		Carrinho.getTotalProdutos();
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getValorUnitario() {
		return valorUnitario;
	}
	public void setValorUnitario(double valorUnitario) {
		this.valorUnitario = valorUnitario;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
		
	@Override
	public String toString() {
		return "Nome: " + nome + "\n" + "Preco: " + valorUnitario;
	}
	@Override
	public int compareTo(Produto p) {
		if(this.getValorUnitario() > p.getValorUnitario()) {
			return 1;
		} else if(this.getValorUnitario() < p.getValorUnitario()){
			return -1;
		} else {
			return this.getNome().compareTo(p.getNome());
		}
	}
}
