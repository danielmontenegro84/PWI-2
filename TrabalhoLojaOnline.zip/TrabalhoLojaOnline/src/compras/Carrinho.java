package compras;

import produtos.*;
import java.util.*;

public final class Carrinho<Produto> implements OperacoesBasicas<Produto>{
	
	private double total;
	private static int totalProdutos;
	TreeSet<Produto>produtos;

	public Carrinho() {
		produtos = new TreeSet<>();
	}
		
	@Override
	public boolean cadastrar(Produto produto) {
		
		return produtos.add(produto);
	}
	
	@Override
	public String formatar() {
		String aux = "";
		for (Produto p : produtos) {
			if(p!=null)
				aux += p.toString() + "\n";
		}
		return aux;
	}	
		
	@Override
	public int totalizar() {
		return produtos.size();
	}
	
	@Override
	public boolean pesquisar(Produto p) {
		return produtos.contains(p);
	}
	
		
	@Override
	public boolean remover(Produto p) {
		
		return produtos.remove(p);
		
	}
		
	public static int getTotalProdutos() {
		return totalProdutos++;
	}
	
	public double calcularTotal() {
		 return totalProdutos - total;
	}
	
	public int exibirHistorico1() {
		return totalProdutos;
	}
	
	public int exibirHistorico2() {
		if(totalProdutos == produtos.size()) {
			return totalProdutos; /* poderia retornar qualquer um dos dois */
		} else if(totalProdutos > produtos.size()) {
			return produtos.size();
		} else {
		return 0;
		}
	}
	public int exibirHistorico3() {
		return totalProdutos - produtos.size();
	}
	
	
	public TreeSet<Produto> getProdutos() {
		return produtos;
	}

	public void setProdutos(TreeSet<Produto> produtos) {
		this.produtos = produtos;
	}
	
}
