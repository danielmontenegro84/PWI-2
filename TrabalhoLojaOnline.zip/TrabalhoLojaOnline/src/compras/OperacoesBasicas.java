package compras;

public interface OperacoesBasicas <T>{
	
	boolean cadastrar(T produto);
	String formatar();
	int totalizar();
	boolean pesquisar(T produto);
	boolean remover(T produto);	
}
